
import { User, Message } from '../types';

const API_BASE_URL = 'http://localhost:5000/api';
const OTP_API_BASE_URL = 'http://localhost:5001/api';

const handleResponse = async (response: Response) => {
  const data = await response.json();
  if (!response.ok) {
    throw new Error(data.message || 'An error occurred');
  }
  return data;
};

// --- Auth ---
export const apiLogin = async (credentials: Pick<User, 'email' | 'password'>) => {
  const response = await fetch(`${API_BASE_URL}/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(credentials),
  });
  return handleResponse(response);
};

export const apiSignup = async (userData: Omit<User, 'id'>) => {
  const response = await fetch(`${API_BASE_URL}/register`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(userData),
  });
  return handleResponse(response);
};

export const apiGoogleLogin = async (userData: { email: string; name?: string }) => {
  const response = await fetch(`${API_BASE_URL}/google-login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(userData),
  });
  return handleResponse(response);
};

export const apiGetMe = async () => {
  const token = localStorage.getItem('vsai-token');
  if (!token) {
    throw new Error('No token found');
  }
  const response = await fetch(`${API_BASE_URL}/me`, {
    headers: {
      'Authorization': `Bearer ${token}`,
    },
  });
  return handleResponse(response);
};

export const apiUpdateUser = async (email: string, userData: Partial<User>) => {
    const response = await fetch(`${API_BASE_URL}/user`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, ...userData }),
    });
    return handleResponse(response);
};

export const apiDeleteUser = async (email: string) => {
    const response = await fetch(`${API_BASE_URL}/user`, {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email }),
    });
    return handleResponse(response);
};

export const apiForgotPassword = async (email: string, newPassword?: string) => {
    const response = await fetch(`${API_BASE_URL}/forgot-password`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, newPassword }),
    });
    return handleResponse(response);
};

// --- OTP ---
export const apiSendOtp = async (email: string) => {
  const response = await fetch(`${OTP_API_BASE_URL}/send-otp`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email }),
  });
  return handleResponse(response);
};

export const apiVerifyOtp = async (email: string, code: string) => {
  const response = await fetch(`${OTP_API_BASE_URL}/verify-otp`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email, code }),
  });
  return handleResponse(response);
};


// --- Chat History ---
export const apiGetChatHistory = async (email: string): Promise<Message[]> => {
  const response = await fetch(`${API_BASE_URL}/chat-history/${email}`);
  const data = await handleResponse(response);
  return data.history || [];
};

export const apiSaveChatHistory = async (email: string, messages: Message[]): Promise<void> => {
  await fetch(`${API_BASE_URL}/chat-history`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email, history: messages }),
  });
};

export const apiClearChatHistory = async (email: string): Promise<void> => {
  await fetch(`${API_BASE_URL}/chat-history/${email}`, {
    method: 'DELETE',
  });
};
